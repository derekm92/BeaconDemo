//
//  RWTItemCell.h
//  ForgetMeNot
//
//  Created by Chris Wagner on 1/30/14.
//  Copyright (c) 2014 Ray Wenderlich Tutorial Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RWTItem;

@interface RWTItemCell : UITableViewCell

@property (strong, nonatomic) RWTItem *item;

@end
